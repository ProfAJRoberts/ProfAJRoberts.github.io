function x=mymin(func,x0,p1,p2,p3)
% Given func(x) is a function to be minimised
% and x0 is an initial guess, returns x as its best estimate
% Copyright AJ Roberts 1994
n=length(x0);
nall=1:n;
vall=1:n+1;
dx=0.1;
tol=0.01;
v=zeros(n,n+1);
f=zeros(1,n+1);
for j=vall
   v(:,j)=x0+(nall==j)'*dx;
   f(j)=feval(func,v(:,j),p1,p2,p3);
end;

while dx>tol
   j =min(find(f==max(f)));
   x0=((sum(v')-v(:,j)')/n)';
   x= -v(:,j) +2*x0;
   fx=feval(func,x,p1,p2,p3);
disp([fx x']);
   if fx>f(j),
disp('shrink');
      x=0.5*(v(:,j)+x0);
      fx=feval(func,x,p1,p2,p3);
disp([fx x']);
   end;
   v(:,j)=x; f(j)=fx;
   dx=max(max(v')-min(v'));
end;

end
