
off echo;

write "\)
\paragraph{Time dependent centre manifold coordinates}
\(";

y_(1):=y_(1) +order_(varepsilon^2,sigma_^2);

y_(2):=y_(2) +order_(varepsilon^2,sigma_^2);

y_(3):=y_(3) +order_(varepsilon^2,sigma_^2);

x_(1):=x_(1) +order_(varepsilon^2,sigma_^2);

x_(2):=x_(2) +order_(varepsilon^2,sigma_^2);

x_(3):=x_(3) +order_(varepsilon^2,sigma_^2);

write "\)
\paragraph{Result centre manifold DEs}
\(";

ff(1):=ff(1) +order_(varepsilon^3,sigma_^3);

ff(2):=ff(2) +order_(varepsilon^3,sigma_^3);

ff(3):=ff(3) +order_(varepsilon^3,sigma_^3);

end;
