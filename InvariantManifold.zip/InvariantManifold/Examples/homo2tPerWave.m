Comment Homogenise period-two wave PDE with given
time-fluctuation of c=c_0+sigma.cos(w*t).  Seek macroscopic
slow waves and neglect frequency 2 fast waves. Here the
expansion to D_x^N naturally truncates at sigma^N terms so
no need to treat sigma as small.  However, the multiplicity
two zero-eigenvalue has generalised eigenvector.  Have coded
'notSmall' into invariantmanifold so procedure is happy to
use generalised e-vecs! For algebraic w and c_0, the case
N=4, takes 8 iterations in 69 secs.   AJR, 31 Aug 2026;
on div,revpri; off allfac,raise,lower; 
on ezgcd;

in_tex "../invariantManifold.tex"$

w:=3; c_0:=1/2;  % optional simplicity
N:=4;            % highest retained derivative
%let sigma^5=>0; % fluctuation order of error---not needed!!
c:=c_0+sigma*cos(w*t);  % trigonometric time fluctuation
a:=1+c; b:=1-c;         % lattice heterogeneities

rhs1 := +a*(-u1+u2+pdf(u2,x)) +b*(-u1+u2-pdf(u2,x));
rhs2 := +b*(-u2+u1+pdf(u1,x)) +a*(-u2+u1-pdf(u1,x));
factor small,df;

E0:=mat((1,1,0,0),(0,0,1,1));
invariantmanifold({x}, 
    mat(( (1+notSmall)/2*u3-(1-notSmall)/2*u4,
          (1+notSmall)/2*u4-(1-notSmall)/2*u3,
          rhs1,rhs2 )),
    mat((0,0)), E0, E0, N+1 )$

depend U,x,t; depend V,x,t;
uu:=( uu where exp(i*~a)=>cos(a)+i*sin(a) )$
uLow:=(uu where small^3=>0)$
write u1 := coeffn(sub({s(1)=U,s(2)=V,small=1},uLow),e_(1,1),1);
write u2 := coeffn(sub({s(1)=U,s(2)=V,small=1},uLow),e_(2,1),1);
write dUdt:=coeffn(sub({s(1)=U,s(2)=V,small=1},dsdt),e_(1,1),1);
write dVdt:=coeffn(sub({s(1)=U,s(2)=V,small=1},dsdt),e_(2,1),1);
end;
