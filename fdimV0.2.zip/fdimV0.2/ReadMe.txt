The function fdim() estimates generalised fractal dimensions
of a set of given points.  To test, execute the script file
eg.m .

This code is based upon traditional methods and is arguably
one of the most accurate in its class, and is reasonably
computationally efficient.  However, I recommend also using
the more accurate code I have that uses multiplicative
multifractals, albeit much more computationally intensive.

Tony Roberts, Dec 2017
