Comment Homogenise period-two wave PDE with given
time-fluctuation of c=c_0+sigma.cos(w*t).  Seek macroscopic
slow waves and neglect frequency 2 fast waves. Here the
expansion to D_x^N naturally truncates at sigma^N terms so
no need to treat sigma as small.  However, the multiplicity
two zero-eigenvalue has generalised eigenvector.  Have coded
'notSmall' into invariantmanifold so procedure is happy to
use generalised e-vecs! For algebraic w and c_0, the case
N=4, takes 8 iterations in 69 secs.   AJR, 31 Aug 2026;
on div,revpri; off allfac,raise,lower; 
on ezgcd;

in_tex "../invariantManifold.tex"$

w:=2; c_0:=1/2;  % optional simplicity, w=2 shows slow-fast resonance
N:=2;            % highest retained derivative
%let sigma^5=>0; % fluctuation order of error---not needed!!
c:=c_0+sigma*cos(w*t);  % trigonometric time fluctuation
a:=1+c; b:=1-c;         % lattice heterogeneities

rhs1 := +a*(-u1+u2+pdf(u2,x)) +b*(-u1+u2-pdf(u2,x));
rhs2 := +b*(-u2+u1+pdf(u1,x)) +a*(-u2+u1-pdf(u1,x));
factor small,df,i;

E0:=mat((1,1,0,0),(0,0,1,1),(1,-1,2*i,-2*i),(1,-1,-2*i,2*i));
invariantmanifold({x}, 
    mat(( (1+notSmall)/2*u3-(1-notSmall)/2*u4,
          (1+notSmall)/2*u4-(1-notSmall)/2*u3,
          rhs1,rhs2 )),
    mat((0,0,2*i,-2*i)), E0, E0, N+1 )$

depend U,x,t; depend V,x,t; depend X,x,t; depend Y,x,t;
uu:=( uu where exp(i*~a)=>cos(a)+i*sin(a) )$
uLow:=(uu where small^3=>0)$
Rename:={s(1)=U,s(2)=V,s(3)=X,s(4)=Y,small=1};
write u1 := coeffn(sub(Rename,uLow),e_(1,1),1);
write u2 := coeffn(sub(Rename,uLow),e_(2,1),1);
write dUdt:=coeffn(sub(Rename,dsdt),e_(1,1),1);
write dVdt:=coeffn(sub(Rename,dsdt),e_(2,1),1);
write dXdt:=coeffn(sub(Rename,dsdt),e_(3,1),1);
write dYdt:=coeffn(sub(Rename,dsdt),e_(4,1),1);
end;
